# LibClassicSpellActionCount-1.0

A small library that provides a function lib:GetActionCount(slot) that returns an action's reagent count for spells. With Patch 1.13.3, Blizzard's own implementation of GetActionCount was broken either deliberately or accidentally. This library offers a working replacement.
